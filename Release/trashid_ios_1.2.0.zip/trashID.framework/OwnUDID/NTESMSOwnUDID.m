#import "NTESMSOwnUDID.h"
#import <CommonCrypto/CommonDigest.h> // Need to import for CC_MD5 access
#import "NTESMSKeychainItemWrapper.h"
#import "NTESMSEncrypt.h"

#ifdef __OPTIMIZE__
#define kOpenUDIDKey uXBzYrppJzzjgrGZ
#define kOpenUDIDAppUIDKey JiuaUJDpRNwJncRB
#define kOpenUDIDTSKey jDISKTANfVedHABz
#define kUDIDKey zginSFfTtbtTXMFZ
#define kUDIDIDKey aXmIkPZVHjfizWhz
#define kUDIDIDKeyGroup ZvlGtFVFIAFOUPeL
#define getDecodeOcString YhtkiJIvvJTCllPQ
#define machineModel yznblGKCwvDopwEE
#define ntesoldvalue lTtyiAFBYlpLFVso
#define saveUDIDToSandbox lgAzcOoaYZWAxpYO
#define getUDIDFromSandbox wqNMlHOqmZRTACbM
#define saveUDIDToOpenUDID VEFMFCdyYwjrHsMJ
#define getUDIDFromOpenUDID UShhhqWzravUPFXv
#define saveUDIDToKeychain pXBvZDnyuyoqOoYZ
#define getUDIDFromKeychain ztxKnBvikvDleVbL
#define generateFreshUDID dADoiEXvETffftDV
#define bundleSeedID juwbnBDlYaACgdbh
#define saveUDIDToSandboxNew uAupRSODhlJvHQjA
#define getUDIDFromSandboxNew dEWghqOoOSkcpZhM
#define getNTESPasswordForUsername ccAHlluSPWJOzQJL
#define andNTESServiceName yDjfmYNSSMWPZbYV
#define storeNTESUsername RbziGPysGpWhRsBv
#define andNTESPassword xgEOpiIqfTpQuanf
#define forNTESServiceName IhoFratWdcwuJywo
#define updateNTESExisting RTMKIzpXyBAfrJxM
#define accessibilityNTES vvuqirDRobCymJEM
#endif

static NSString *kOpenUDIDKey        = @"OpenUDID";
static NSString *kOpenUDIDAppUIDKey  = @"OpenUDID_appUID";
static NSString *kOpenUDIDTSKey      = @"OpenUDID_createdTS";

static NSString *kUDIDKey = @"NTESUniqueID_UDID";
static NSString *kUDIDIDKey = @"NTESUniqueID_OPENUUID";
static NSString *kUDIDIDKeyGroup = @"com.netease.uniqueid";
#define newkUDIDSandBox         @"wEtLmMeDtVcBRehm"
#define newkUDIDKeychain        @"mUTrGBUVJwQHnkQs"
#define newkUDIDKeychainS       @"aLwaYmZetYJceQFP"

typedef struct _NEEncodedString {
    char* origstr;
    int size;
    int type;
} NEEncodedString;
// aes key:kfv61U5rA!fpJCiq
#define NE_ENCODE_XOR 0
static unsigned char _WUUPGD7CSPNPBYAFEQPW[] = {0x20,0x2D,0x3D,0x7D,0x7A,0x1E,0x7E,0x39,0xA,0x6A,0x2D,0x3B,0x1,0x8,0x22,0x3A,0x4b};
static NEEncodedString _WUUPGD7CSPNP= { (char *)_WUUPGD7CSPNPBYAFEQPW, sizeof(_WUUPGD7CSPNPBYAFEQPW), NE_ENCODE_XOR };

#import <objc/runtime.h>
#import <sys/sysctl.h>
#import <mach/mach.h>
#import <dlfcn.h>
#import "NTESMSDeviceInfo.h"

#define __NTESMS_SEC_ATTR__ __attribute__((always_inline))

#ifdef __OPTIMIZE__
#define detect_debugger mvczqLWxnntnCOfX
#define detect_injection sLxBJFsmCvzkaBLg
#define className IZjvpItiKaVLunCk
#endif

static void detect_debugger() __NTESMS_SEC_ATTR__;
void detect_debugger() {
    size_t size = sizeof(struct kinfo_proc);
    struct kinfo_proc info;
    int name[4];
    memset(&info, 0, sizeof(struct kinfo_proc));
    
    name[0] = CTL_KERN;
    name[1] = KERN_PROC;
    name[2] = KERN_PROC_PID;
    name[3] = getpid();
    
    if(-1 == sysctl(name, 4, &info, &size, NULL, 0)) {
        return;
    }
    
    if(info.kp_proc.p_flag & P_TRACED) {
        DLog(@"found debugger");
        [[NTESMSDeviceInfo sharedInstance] setSecurityCheck];
    }
}

static void detect_injection(const char *className) __NTESMS_SEC_ATTR__;
void detect_injection(const char *className) {
    if(!className) {
        return;
    }
    
    NSString *targetModule = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleName"];
    if(!targetModule) {
        return;
    }
    
    //实例方法
    Class aClass = objc_getClass(className);
    if(!aClass) {
        return;
    }
    
    unsigned int nMethods;
    Method *methods = class_copyMethodList(aClass, &nMethods);
    BOOL status = FALSE;
    for(int i = 0; i < nMethods; i++) {
        Method m = methods[i];
        DLog(@"check - [%s %@]", class_getName(aClass), NSStringFromSelector(method_getName(m)));
        IMP imp = method_getImplementation(m);
        if(!imp) {
            continue;
        }
        
        Dl_info info;
        if(!dladdr(imp, &info)) {
            continue;
        }
        
        NSString *baseModule = [[NSString stringWithUTF8String:info.dli_fname] lastPathComponent];
        if(baseModule && ![baseModule isEqualToString:targetModule]) {
            [[NTESMSDeviceInfo sharedInstance] setSecurityCheck];
            DLog(@"found instance injected imp: %@ in %@", NSStringFromSelector(method_getName(m)), baseModule);
            status = TRUE;
            break;
        }
    }
    free(methods);
    if(status) {
        return;
    }
    
    //类方法
    aClass = object_getClass(aClass);
    if(!aClass) {
        return;
    }
    
    methods = class_copyMethodList(aClass, &nMethods);
    for(int i = 0; i < nMethods; i++) {
        Method m = methods[i];
        DLog(@"check + [%s %@]", class_getName(aClass), NSStringFromSelector(method_getName(m)));
        IMP imp = method_getImplementation(m);
        if(!imp) {
            continue;
        }
        
        Dl_info info;
        if(!dladdr(imp, &info)) {
            continue;
        }
        
        NSString *baseModule = [[NSString stringWithUTF8String:info.dli_fname] lastPathComponent];
        if(baseModule && ![baseModule isEqualToString:targetModule]) {
            [[NTESMSDeviceInfo sharedInstance] setSecurityCheck];
            DLog(@"found class injected imp: %@ in %@", NSStringFromSelector(method_getName(m)), baseModule);
            break;
        }
    }
    free(methods);
}

@interface NTESMSOwnUDID (Private)

@end

@implementation NTESMSOwnUDID

// Main public method that returns the OpenUDID
// This method will generate and store the OpenUDID if it doesn't exist, typically the first time it is called
// It will return the null udid (forty zeros) if the user has somehow opted this app out (this is subject to 3rd party implementation)
// Otherwise, it will register the current app and return the OpenUDID
//
+ (NSString*)uuidvalue {
    NSString *udid = nil;
    detect_debugger();
#ifdef __OPTIMIZE__
    detect_injection("OqSEEObxwCjzSeUB");
#else
    detect_injection("NTESMSOwnUDID");
#endif
    
    udid = [self getUDIDFromSandboxNew];
    if (udid && udid.length > 0) {
        [self storeNTESUsername:newkUDIDKeychain andNTESPassword:udid forNTESServiceName:newkUDIDKeychainS updateNTESExisting:YES error:nil];
    } else {
        udid = [self getNTESPasswordForUsername:newkUDIDKeychain andNTESServiceName:newkUDIDKeychainS error:nil];
        if (udid && udid.length > 0) {
            [self saveUDIDToSandboxNew:udid];
        }
    }
    
    if(udid && [udid length]) {
        NSData *bData = [NTESMSEncrypt dataWithBase64EncodedString:udid];
        NSData *deData = [NTESMSEncrypt AES128_ECB_7_DecryptWithKey:bData key:[self getDecodeOcString:&_WUUPGD7CSPNP]];
        NSData *model = [[self machineModel] dataUsingEncoding:NSUTF8StringEncoding];
        if(!bData || !deData || !model) {
            return udid;
        }
        
        if([model isEqualToData:[deData subdataWithRange:NSMakeRange(0, [model length])]]) {
            return udid;
        }
        
        //MD5(MD5("^_^Illegal+udid{_}")):68b7611860afde6e3ccad8c60f97d540
        return @"68b7611860afde6e3ccad8c60f97d540";
    }
    
    udid = [self ntesoldvalue];
    if(udid) {
        DLog(@"found old version uuid, start to migrant");
    } else {
        udid = [self generateFreshUDID];
    }
    
    NSMutableData *data = [[NSMutableData alloc] init];
    uint32_t time = (uint32_t)[[NSDate date] timeIntervalSince1970];
    time = time << 24 | time >> 8;
    [data appendData:[NSData dataWithBytes:&time length:4]];
    long pad1 = 1, pad2 = 63;
    [data appendBytes:&pad1 length:1];
    [data appendBytes:&pad2 length:2];
    [data appendData:[udid dataUsingEncoding:NSUTF8StringEncoding]];
    [data appendData:[[NTESMSEncrypt MD5En:data] dataUsingEncoding:NSUTF8StringEncoding]];
    NSMutableData *penData = [[NSMutableData alloc] init];
    [penData appendData:[[self machineModel] dataUsingEncoding:NSUTF8StringEncoding]];
    [penData appendData:[data copy]];
    NSData *enData = [NTESMSEncrypt AES128_ECB_7_EncryptWithData:[penData copy]
                                                     key:[self getDecodeOcString:&_WUUPGD7CSPNP]];
    if(enData && [enData length]) {
        udid = [NTESMSEncrypt base64EncodedStringFrom:enData];
        [self saveUDIDToSandboxNew:udid];
        [self storeNTESUsername:newkUDIDKeychain andNTESPassword:udid forNTESServiceName:newkUDIDKeychainS updateNTESExisting:YES error:nil];
        
        return udid;
    }
    
    return udid;
}

+ (NSString *) getDecodeOcString:(NEEncodedString *)str {
    char seed = str->origstr[str->size-1];
    
    int j = 0;
    
    do{
        str->origstr[j] ^= seed;
        j++;
    }while(j < str->size);
    
    return [[NSString alloc] initWithBytesNoCopy:str->origstr length:str->size-1 encoding:NSUTF8StringEncoding freeWhenDone:0];
}

+ (NSString *)machineModel {
    static dispatch_once_t one;
    static NSString *model;
    dispatch_once(&one, ^{
        size_t size;
        sysctlbyname("hw.machine", NULL, &size, NULL, 0);
        char *machine = malloc(size);
        sysctlbyname("hw.machine", machine, &size, NULL, 0);
        model = [NSString stringWithUTF8String:machine];
        free(machine);
    });
    return model;
}

+ (NSString*)ntesoldvalue {

    NSString *udid = nil;
    
    detect_debugger();
#ifdef __OPTIMIZE__
    detect_injection("OqSEEObxwCjzSeUB");
#else
    detect_injection("NTESMSOwnUDID");
#endif
    
    // 先从自己的沙盒读取,有则直接使用,同时保存到key_chain中
    udid = [self getUDIDFromSandbox];
    if (udid && udid.length > 0) {
        //[self saveUDIDToKeychain:udid];
    }
    else{
        // 以前的版本是通过OpenUDID获取的，保证app升级前后的udid值一样，从OpenUDID读取，有则使用，并保存到程序沙盒以及key_chain中
        udid = [self getUDIDFromOpenUDID];
        if (udid && udid.length > 0) {
            // 保存到自己app的沙盒以及key-chain中
            //[self saveUDIDToSandbox:udid];
            //[self saveUDIDToKeychain:udid];
        }
        else{
            // 程序都删掉了或者iPhone被还原了。从key——chain读取，有则保存到沙盒和OpenUDID，保证DA SDK能获取一样的UDID
            udid = [self getUDIDFromKeychain];
            if (udid && udid.length > 0) {
                //[self saveUDIDToSandbox:udid];
                //[self saveUDIDToOpenUDID:udid];
            }
            else{
                // iphone被刷机或者抹掉所有数据和配置，重新生成全新的udid，同时保存到沙盒，key-chain, OpenUDID
                //udid = [self generateFreshUDID];
                //[self saveUDIDToSandbox:udid];
                //[self saveUDIDToKeychain:udid];
                //[self saveUDIDToOpenUDID:udid];
            }
        }
    }
    
    return udid;
}

+ (void) saveUDIDToSandbox:(NSString *)udid {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if (defaults) {
        [defaults setObject:udid forKey:kUDIDKey];
    }
}

+ (void) saveUDIDToSandboxNew:(NSString *)udid {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if (defaults) {
        [defaults setObject:udid forKey:newkUDIDSandBox];
    }
}

+ (NSString *) getUDIDFromSandbox{
    
    NSString *udid = nil;
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if (defaults) {
        udid = [defaults objectForKey:kUDIDKey];
    }
    
    return udid;
}

+ (NSString *) getUDIDFromSandboxNew {
    
    NSString *udid = nil;
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if (defaults) {
        udid = [defaults objectForKey:newkUDIDSandBox];
    }
    
    return udid;
}

+ (void) saveUDIDToOpenUDID:(NSString *)udid
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if (defaults) {
        NSMutableDictionary *localDict = [NSMutableDictionary dictionaryWithCapacity:4];
        [localDict setObject:udid forKey:kOpenUDIDKey];
        
        CFUUIDRef uuid = CFUUIDCreate(NULL);
        NSString * appUID = (NSString *)CFBridgingRelease(CFUUIDCreateString(NULL, uuid));
        CFRelease(uuid);
        
        [localDict setObject:appUID forKey:kOpenUDIDAppUIDKey];
        [localDict setObject:[NSDate date] forKey:kOpenUDIDTSKey];
        
        [defaults setObject:localDict forKey:kOpenUDIDKey];
    }
    
}

+ (NSString *) getUDIDFromOpenUDID{
    
    NSString *udid = nil;
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if (defaults) {
        id localDict = [defaults objectForKey:kOpenUDIDKey];
        if ([localDict isKindOfClass:[NSDictionary class]]) {
            localDict = [NSMutableDictionary dictionaryWithDictionary:localDict];
            udid = [localDict objectForKey:kOpenUDIDKey];
        }
    }
    
    return udid;
}

+ (void) saveUDIDToKeychain:(NSString *)udid {
    @try {
        NSString *accessGroupValue = [NSString stringWithFormat:@"%@.%@", [self bundleSeedID], kUDIDIDKeyGroup];
        NTESMSKeychainItemWrapper *keyWrapper=[[NTESMSKeychainItemWrapper alloc] initWithIdentifier:kUDIDIDKey accessGroup:accessGroupValue];
        if (keyWrapper) {
            [keyWrapper setObject:udid forKey:(__bridge id)kSecValueData];
        }
    }
    @catch (NSException *exception) {
        
    }

}

+ (NSString *) getUDIDFromKeychain{
    
    NSString *udid = nil;
    
    @try {
        NSString *accessGroupValue = [NSString stringWithFormat:@"%@.%@", [self bundleSeedID], kUDIDIDKeyGroup];
        NTESMSKeychainItemWrapper *keyWrapper=[[NTESMSKeychainItemWrapper alloc] initWithIdentifier:kUDIDIDKey accessGroup:accessGroupValue];
        if (keyWrapper) {
            udid = [keyWrapper objectForKey:(__bridge id)kSecValueData];
        }
    }
    @catch (NSException *exception) {
        
    }
    
    return udid;
}


+ (NSString*) generateFreshUDID {
    
    NSString* _UDID = nil;
    
    // Next we generate a UUID.
    // UUIDs (Universally Unique Identifiers), also known as GUIDs (Globally Unique Identifiers) or IIDs
    // (Interface Identifiers), are 128-bit values guaranteed to be unique. A UUID is made unique over
    // both space and time by combining a value unique to the computer on which it was generated—usually the
    // Ethernet hardware address—and a value representing the number of 100-nanosecond intervals since
    // October 15, 1582 at 00:00:00.
    // We then hash this UUID with md5 to get 32 bytes, and then add 4 extra random bytes
    // Collision is possible of course, but unlikely and suitable for most industry needs (e.g. aggregate tracking)
    //
    if (_UDID==nil) {
        
        @try {
            NSString *ver = [UIDevice currentDevice].systemVersion;
            
            if (ver && ver.floatValue >= 6.0) {
                //Available in iOS 6.0 and later
                _UDID = [UIDevice currentDevice].identifierForVendor.UUIDString;
            }
            else
            {
                CFUUIDRef uuid = CFUUIDCreate(kCFAllocatorDefault);
                CFStringRef cfstring = CFUUIDCreateString(kCFAllocatorDefault, uuid);
                const char *cStr = CFStringGetCStringPtr(cfstring,CFStringGetFastestEncoding(cfstring));
                unsigned char result[16];
                CC_MD5( cStr, (CC_LONG)strlen(cStr), result );
                CFRelease(uuid);
                CFRelease(cfstring);
                
                _UDID = [NSString stringWithFormat:
                         @"%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%08lx",
                         result[0], result[1], result[2], result[3],
                         result[4], result[5], result[6], result[7],
                         result[8], result[9], result[10], result[11],
                         result[12], result[13], result[14], result[15],
                         (unsigned long)(arc4random() % NSUIntegerMax)];
            }
        }
        @catch (NSException *exception) {
            
        }
        
        
    }
    
    return _UDID;
}

+ (NSString *)bundleSeedID {
    NSString *bundleSeedID = nil;
    
    NSDictionary *query = [NSDictionary dictionaryWithObjectsAndKeys:
                           (__bridge id)(kSecClassGenericPassword), kSecClass,
                           @"bundleSeedID", kSecAttrAccount,
                           @"", kSecAttrService,
                           (id)kCFBooleanTrue, kSecReturnAttributes,
                           nil];
    CFDictionaryRef result = nil;
    OSStatus status = SecItemCopyMatching((__bridge CFDictionaryRef)query, (CFTypeRef *)&result);
    if (status == errSecItemNotFound)
        status = SecItemAdd((__bridge CFDictionaryRef)query, (CFTypeRef *)&result);
    
    if (status == errSecSuccess)
    {
        NSString *accessGroup = [(__bridge NSDictionary *)result objectForKey:(__bridge id)(kSecAttrAccessGroup)];
        NSArray *components = [accessGroup componentsSeparatedByString:@"."];
        bundleSeedID = [[components objectEnumerator] nextObject];
        CFRelease(result);
    }

    return bundleSeedID;
}

+ (NSString *)getNTESPasswordForUsername:(NSString *)name andNTESServiceName:(NSString *)serviceName error:(NSError **)error {
    NSString *uuid = nil;
    if(name && serviceName){
        NSArray* attr = [[NSArray alloc]  initWithObjects:(__bridge id)kSecClass,kSecAttrAccount,kSecAttrService,(__bridge id)kSecReturnAttributes,(__bridge id)kSecReturnData,nil];
        NSArray* objs = [[NSArray alloc] initWithObjects:(__bridge id)kSecClassGenericPassword,name,serviceName,(id)kCFBooleanTrue,(id)kCFBooleanTrue,nil];
        NSMutableDictionary* dic = [[NSMutableDictionary alloc] initWithObjects:objs forKeys:attr];
        NSData *udidValue = nil;
        CFTypeRef result = (__bridge CFTypeRef)udidValue;
        OSStatus status = SecItemCopyMatching((CFDictionaryRef)dic, &result);
        if(status == noErr) {
            NSData* uuidData = [(__bridge NSDictionary *)result objectForKey:(__bridge id)(kSecValueData)];
            uuid = [[NSString alloc] initWithData:uuidData encoding:NSUTF8StringEncoding];
            CFRelease(result);
        } else {
            if(error)
                *error = [NSError errorWithDomain:@"" code:status userInfo:nil];
        }
    }
    return uuid;
}

+ (BOOL)storeNTESUsername:(NSString *)name andNTESPassword:(NSString *)password forNTESServiceName:(NSString *)serviceName updateNTESExisting:(BOOL)update error:(NSError **)error {
    return [self storeNTESUsername:name andNTESPassword:password forNTESServiceName:serviceName updateNTESExisting:update accessibilityNTES:(NSString*)kSecAttrAccessibleWhenUnlocked error:error];
}

+ (BOOL)storeNTESUsername:(NSString *)name andNTESPassword:(NSString *)password forNTESServiceName:(NSString *)serviceName updateNTESExisting:(BOOL)update accessibilityNTES:(NSString *)access error:(NSError **)error {
    if(name && serviceName){
        NSString * pwd = [self getNTESPasswordForUsername:name andNTESServiceName:serviceName error:nil];
        NSArray* attr = nil;
        NSArray* objs = nil;
        OSStatus status = 0;
        if(pwd != nil){
            if(update){
                attr = [[NSArray alloc] initWithObjects:(NSString*)kSecClass,kSecAttrService,kSecAttrLabel,kSecAttrAccount,kSecAttrAccessible, nil];
                objs = [[NSArray alloc] initWithObjects:(NSString*)kSecClassGenericPassword,serviceName,serviceName,name,access,nil];
                NSMutableDictionary* dic = [[NSMutableDictionary alloc] initWithObjects:objs forKeys:attr];
                
                NSData *passData = [password dataUsingEncoding:NSUTF8StringEncoding];
                NSDictionary* updateDic = [NSDictionary dictionaryWithObject:passData forKey:(NSString*)kSecValueData];
                
                status = SecItemUpdate((CFDictionaryRef)dic, (CFDictionaryRef)updateDic);
            }
        }else{
            attr = [[NSArray alloc] initWithObjects:(__bridge id)kSecClass,kSecAttrService,kSecAttrLabel,kSecAttrAccount,kSecValueData,kSecAttrAccessible, nil];
            objs = [[NSArray alloc] initWithObjects:(__bridge id)kSecClassGenericPassword,serviceName,serviceName,name,[password dataUsingEncoding:NSUTF8StringEncoding],access,nil];
            NSMutableDictionary* dic = [[NSMutableDictionary alloc] initWithObjects:objs forKeys:attr];
            status = SecItemAdd((__bridge CFDictionaryRef)dic, 0);
        }
        
        if(status != noErr && error){
            *error = [NSError errorWithDomain:@"" code:status userInfo:nil];
            return NO;
        }
        return  YES;
    }
    return NO;
}

+ (BOOL)isConsistent {
    detect_debugger();
#ifdef __OPTIMIZE__
    detect_injection("OqSEEObxwCjzSeUB");
#else
    detect_injection("NTESMSOwnUDID");
#endif
    
    NSString *uuid2 = [self getUDIDFromSandboxNew];
    NSString *uuid3 = [self getNTESPasswordForUsername:newkUDIDKeychain andNTESServiceName:newkUDIDKeychainS error:nil];
    
    if(!uuid2 || !uuid3) {
        return false;
    }
    
    if([uuid2 isEqualToString:uuid3]) {
        return true;
    }
    
    return false;
}

@end
