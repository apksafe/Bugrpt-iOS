//
//  trashID.h
//  trashID
//
//  Created by NetEase on 15-3-3.
//  Copyright (c) 2015年 NetEase. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NTESMSTrashID : NSObject

/* 单例模式，接口调用如下:
 * NSString *value = [[NTESMSTrashID sharedInstance] trashIDWithLongitude:@"12.344" andLatitude:@"455.334"];
 * 如果不喜欢单例模式,接口调用如下:
 * NSString *value = [[[NTESMSTrashID alloc] init] trashIDWithLongitude:@"12.344" andLatitude:@"455.334"];
 */
+ (id)sharedInstance;

/* 返回trashID
 * @pagram lo,经度。如果没有就传递nil
 * @pagram la,纬度。如果没有就传递nil
 */
- (NSString *)trashIDWithLongitude:(NSString *)lo andLatitude:(NSString *)la;

/* 查看SDK的版本号
 * @return, SDK的版本信息
 */
- (NSString *)sdkVersion;

/* 判断设备是否越狱
 * @return, BOOL YES:越狱;NO:非越狱
 */
- (BOOL)isJailbreak;

@end
