//
//  NTESCrashReporterLite.h
//  BugrptExtension
//
//  Created by Monkey on 15/11/24.
//  Copyright © 2015年 NetEase. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NTESExtensionCrashReporter : NSObject

/*
 * 单例模式
 */
+ (NTESExtensionCrashReporter *)sharedInstance;

/*
 *  初始化BugrptExtension崩溃上报,开启App Group
 *  初始化方法：
 *  iOS Extension : 在 ViewController 的 initWithCoder: 方法中调用
 *  WatchKit Extension : 在 WKInterfaceController 的 init 方法中调用
 *
 */
-(void)initWithApplicationGroupIdentifier:(NSString *)identifier;

/*
 *  设置是否开启打印Log信息，默认关闭，请在初始化方法之前调用
 *  @param enable  设置为YES，打印Log信息， Release产品中请务必设置为NO
 */
-(void)enableLog:(BOOL) enable;

@end
