//
//  NTESBugrptWOCrashReporter.h
//  NTESBugrptWatchOS
//
//  Created by NetEase on 16/5/17.
//  Copyright © 2016年 NetEase. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NTESBugrptWOCrashReporter : NSObject

+ (instancetype) sharedInstance;
- (BOOL) start;
- (void) enableLog:(BOOL)enable;

@end
