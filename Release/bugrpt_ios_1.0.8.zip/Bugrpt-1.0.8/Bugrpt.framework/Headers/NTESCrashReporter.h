//
//  bugrpt.h
//  bugrpt
//
//  Created by Monkey on 15/3/31.
//  Copyright (c) 2015年 Netease. All rights reserved.
//

#import <Foundation/Foundation.h>
#include <UIKit/UIKit.h>

#pragma mark - Interfaces for OC

@interface NTESCrashReporter : NSObject

/*
 * 单例模式
 */
+ (NTESCrashReporter *)sharedInstance;

/* iOS崩溃收集初始化接口
 * @pagram appkey, 在Bugrpt的页面注册产品时生成的，只有合法的appkey才能启用crash捕获等功能
 * @pagram customParams, 产品需要传递的自定义参数, 不传默认为空
 */
- (void) iosCrashInitWithAppId:(NSString*) appId customParams:(NSString *)customParams;

/* iOS崩溃收集初始化接口
 * 以前旧版本没有appid，请使用该接口
 * @pagram customParams, 产品需要传递的自定义参数, 不传默认为空
 */
- (void) iosCrashInit:(NSString *)customParams;

/*
 *使用测试服务器地址设为YES，默认使用正式服务器为NO
 */
-(void)setUseTestAddr:(BOOL) useTestAddr;
/*
 *开启Log显示
 */
-(void) enableLog:(BOOL) enabled;

/*
 *发送Lua层的dump信息
 */
+ (void)sendLuaReportsToServer:(NSDictionary*) dic;

/*
 *发送JS层的dump信息
 */
- (void)sendJSReportsToServer:(const char*)reason trace:(const char*)trace tag:(const char*)tag;

@end


