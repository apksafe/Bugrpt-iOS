//
//  NTESExtensionCrashReporter.h
//
//  Created by Monkey on 15/11/24.
//  Copyright © 2015年 NetEase. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NTESExtensionCrashReporter : NSObject

/**
*  单例
*
*  @return 返回NTESExtensionCrashReporter的对象
*/
+ (NTESExtensionCrashReporter *)sharedInstance;

/**
 *  初始化App Extension或者watch os 1 extension的崩溃上报,
 *
 *  @param identifier App-Goups的identifier
 *
 *  @说明 (1)需要开启App Group
         (2)App Extension:在 ViewController的initWithCoder:方法中调用
         (3)WatchKit Extension:在WKInterfaceController的init方法中调用
 */
- (void)initWithApplicationGroupIdentifier:(NSString *)identifier;

/**
 *  设置是否开启打印Log信息，默认关闭，请在初始化方法之前调用
 *
 *  @param enable 设置为YES，打印Log信息
 */
- (void)enableLog:(BOOL)enable;

@end
